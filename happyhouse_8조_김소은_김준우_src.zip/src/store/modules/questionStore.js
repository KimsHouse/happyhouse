const questionStore = {
  namespaced: true,
  state: {},
  getters: {},
  mutations: {},
  actions: {},
};

export default questionStore;
