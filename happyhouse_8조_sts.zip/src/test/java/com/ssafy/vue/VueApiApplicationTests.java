package com.ssafy.vue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
